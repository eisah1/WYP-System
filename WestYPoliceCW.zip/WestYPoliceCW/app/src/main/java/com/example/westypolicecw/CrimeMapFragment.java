package com.example.westypolicecw;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class CrimeMapFragment extends Fragment implements OnMapReadyCallback {

    private double lat = 53.8008;   // default (Leeds area)
    private double lng = -1.5491;
    private String title = "Crime";
    private String snippet = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_crime_map, container, false);

        // read bundle from list/search fragment
        if (getArguments() != null) {
            lat = getArguments().getDouble("lat", lat);
            lng = getArguments().getDouble("lng", lng);
            title = getArguments().getString("title", title);
            snippet = getArguments().getString("snippet", snippet);
        }

        // load Google map inside this fragment
        SupportMapFragment mapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map_container);

        if (mapFragment == null) {
            mapFragment = SupportMapFragment.newInstance();
            getChildFragmentManager().beginTransaction()
                    .replace(R.id.map_container, mapFragment)
                    .commit();
        }

        mapFragment.getMapAsync(this);

        return v;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        LatLng point = new LatLng(lat, lng);

        googleMap.addMarker(new MarkerOptions()
                .position(point)
                .title(title)
                .snippet(snippet));

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(point, 12f));
    }
}
