package com.example.westypolicecw;

import android.content.ContentValues;
import android.content.Intent;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.westypolicecw.db.CrimeDbHelper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = "HomeLifecycle";

    private Button btnAllCrimes, btnSearch, btnImportCsv, btnAdminCrud, btnLogout;

    private CrimeDbHelper db;
    private String email;
    private boolean isAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = new CrimeDbHelper(this);

        email = getIntent().getStringExtra("email");
        if (email == null) email = "";

        isAdmin = db.isAdmin(email);

        btnAllCrimes = findViewById(R.id.btnAllCrimes);
        btnSearch = findViewById(R.id.btnSearch);
        btnImportCsv = findViewById(R.id.btnImportCsv);
        btnAdminCrud = findViewById(R.id.btnAdminCrud);
        btnLogout = findViewById(R.id.btnLogout);

        if (!isAdmin) {
            btnImportCsv.setVisibility(Button.GONE);
            btnAdminCrud.setVisibility(Button.GONE);
        }

        loadFragment(new CrimeListFragment());

        btnAllCrimes.setOnClickListener(v -> loadFragment(new CrimeListFragment()));
        btnSearch.setOnClickListener(v -> loadFragment(new CrimeSearchFragment()));

        btnImportCsv.setOnClickListener(v -> {
            if (isAdmin) importCrimesFromCsv();
        });

        btnAdminCrud.setOnClickListener(v -> {
            if (isAdmin) startActivity(new Intent(this, AdminCrudActivity.class));
        });

        btnLogout.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void loadFragment(Fragment f) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, f)
                .commit();
    }

    // ================= CSV IMPORT (FIXED) =================
    private void importCrimesFromCsv() {
        SQLiteDatabase sdb = db.getWritableDatabase();
        sdb.beginTransaction();

        try {
            sdb.execSQL("DELETE FROM Crimes");

            InputStream is = getResources().openRawResource(R.raw.crimeyorkshire);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            String line;
            boolean header = true;

            while ((line = br.readLine()) != null) {
                if (header) {
                    header = false;
                    continue;
                }

                // CSV-safe split (handles commas inside quotes)
                String[] c = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                if (c.length < 12) continue;

                ContentValues cv = new ContentValues();
                cv.put("crime_id", clean(c[0]));
                cv.put("month", clean(c[1]));
                cv.put("reported_by", clean(c[2]));
                cv.put("falls_within", clean(c[3]));
                cv.put("longitude", parseDoubleSafe(clean(c[4])));
                cv.put("latitude", parseDoubleSafe(clean(c[5])));
                cv.put("location", clean(c[6]));
                cv.put("lsoa_code", clean(c[7]));
                cv.put("lsoa_name", clean(c[8]));
                cv.put("crime_type", clean(c[9]));
                cv.put("last_outcome", clean(c[10]));
                cv.put("context", clean(c[11]));

                sdb.insertWithOnConflict("Crimes", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }

            sdb.setTransactionSuccessful();

            long count = DatabaseUtils.queryNumEntries(sdb, "Crimes");
            Toast.makeText(this, "Dataset imported! Rows: " + count, Toast.LENGTH_LONG).show();

            loadFragment(new CrimeListFragment());

        } catch (Exception e) {
            Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            sdb.endTransaction();
        }
    }

    private String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1) {
            s = s.substring(1, s.length() - 1);
        }
        return s;
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s); }
        catch (Exception e) { return 0.0; }
    }

    // lifecycle logging
    @Override protected void onStart(){ super.onStart(); Log.d(TAG,"onStart"); }
    @Override protected void onResume(){ super.onResume(); Log.d(TAG,"onResume"); }
    @Override protected void onPause(){ super.onPause(); Log.d(TAG,"onPause"); }
    @Override protected void onStop(){ super.onStop(); Log.d(TAG,"onStop"); }
    @Override protected void onDestroy(){ super.onDestroy(); Log.d(TAG,"onDestroy"); }
}
