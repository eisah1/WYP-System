package com.example.westypolicecw.models;

public class Crime {
    public String crimeId, month, reportedBy, fallsWithin, location, lsoaCode, lsoaName, crimeType, lastOutcome, context;
    public double longitude, latitude;

    public Crime(String crimeId, String month, String reportedBy, String fallsWithin,
                 double longitude, double latitude, String location, String lsoaCode,
                 String lsoaName, String crimeType, String lastOutcome, String context) {
        this.crimeId = crimeId;
        this.month = month;
        this.reportedBy = reportedBy;
        this.fallsWithin = fallsWithin;
        this.longitude = longitude;
        this.latitude = latitude;
        this.location = location;
        this.lsoaCode = lsoaCode;
        this.lsoaName = lsoaName;
        this.crimeType = crimeType;
        this.lastOutcome = lastOutcome;
        this.context = context;
    }
}
