package com.example.westypolicecw.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.westypolicecw.models.Crime;

public class CrimeDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "west_yorkshire_crimes.db";
    private static final int DB_VERSION = 1;

    public CrimeDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL," +
                "is_admin INTEGER DEFAULT 0)");

        db.execSQL("CREATE TABLE IF NOT EXISTS Crimes (" +
                "crime_id TEXT PRIMARY KEY," +
                "month TEXT," +
                "reported_by TEXT," +
                "falls_within TEXT," +
                "longitude REAL," +
                "latitude REAL," +
                "location TEXT," +
                "lsoa_code TEXT," +
                "lsoa_name TEXT," +
                "crime_type TEXT," +
                "last_outcome TEXT," +
                "context TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        db.execSQL("DROP TABLE IF EXISTS Crimes");
        onCreate(db);
    }

    // ---------- USERS ----------
    public boolean insertUser(String email, String password, boolean isAdmin) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("email", email);
        cv.put("password", password);
        cv.put("is_admin", isAdmin ? 1 : 0);
        return db.insert("Users", null, cv) != -1;
    }

    public boolean checkUserEmail(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Users WHERE email=?", new String[]{email});
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Users WHERE email=? AND password=?",
                new String[]{email, password});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean isAdmin(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT is_admin FROM Users WHERE email=?",
                new String[]{email});
        boolean admin = false;
        if (c.moveToFirst()) admin = c.getInt(0) == 1;
        c.close();
        return admin;
    }

    // ---------- CRIMES ----------
    public long insertCrime(Crime cr) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("crime_id", cr.crimeId);
        cv.put("month", cr.month);
        cv.put("reported_by", cr.reportedBy);
        cv.put("falls_within", cr.fallsWithin);
        cv.put("longitude", cr.longitude);
        cv.put("latitude", cr.latitude);
        cv.put("location", cr.location);
        cv.put("lsoa_code", cr.lsoaCode);
        cv.put("lsoa_name", cr.lsoaName);
        cv.put("crime_type", cr.crimeType);
        cv.put("last_outcome", cr.lastOutcome);
        cv.put("context", cr.context);

        return db.insertWithOnConflict("Crimes", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public Cursor getAllCrimes() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM Crimes", null);
    }

    public Cursor searchCrimes(String column, String query) {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM Crimes WHERE " + column + " LIKE ?",
                new String[]{"%" + query + "%"});
    }

    public int updateCrime(Crime cr) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("month", cr.month);
        cv.put("crime_type", cr.crimeType);
        cv.put("location", cr.location);
        cv.put("latitude", cr.latitude);
        cv.put("longitude", cr.longitude);

        return db.update("Crimes", cv, "crime_id=?", new String[]{cr.crimeId});
    }

    public int deleteCrime(String crimeId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("Crimes", "crime_id=?", new String[]{crimeId});
    }
}
