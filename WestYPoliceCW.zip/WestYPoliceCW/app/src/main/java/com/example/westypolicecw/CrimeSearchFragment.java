package com.example.westypolicecw;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.westypolicecw.adapters.CrimeAdapter;
import com.example.westypolicecw.db.CrimeDbHelper;
import com.example.westypolicecw.models.Crime;

import java.util.ArrayList;

public class CrimeSearchFragment extends Fragment {

    private Spinner spinnerField;
    private EditText etQuery;
    private Button btnSearch;
    private RecyclerView rvResults;

    private CrimeDbHelper db;

    private final String[] fields = {"Month", "Crime Type", "LSOA Name", "Reported By", "Location"};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_crime_search, container, false);

        spinnerField = v.findViewById(R.id.spinnerField);
        etQuery = v.findViewById(R.id.etQuery);
        btnSearch = v.findViewById(R.id.btnSearch);
        rvResults = v.findViewById(R.id.rvResults);

        rvResults.setLayoutManager(new LinearLayoutManager(getContext()));

        db = new CrimeDbHelper(requireContext());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                fields
        );
        spinnerField.setAdapter(adapter);

        btnSearch.setOnClickListener(view -> runSearch());

        return v;
    }

    private void runSearch() {
        String query = etQuery.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(getContext(), "Enter search text", Toast.LENGTH_SHORT).show();
            return;
        }

        String selected = spinnerField.getSelectedItem().toString();
        String column = mapFieldToColumn(selected);

        ArrayList<Crime> list = new ArrayList<>();
        Cursor c = db.searchCrimes(column, query);

        while (c.moveToNext()) {
            list.add(new Crime(
                    c.getString(c.getColumnIndexOrThrow("crime_id")),
                    c.getString(c.getColumnIndexOrThrow("month")),
                    c.getString(c.getColumnIndexOrThrow("reported_by")),
                    c.getString(c.getColumnIndexOrThrow("falls_within")),
                    c.getDouble(c.getColumnIndexOrThrow("longitude")),
                    c.getDouble(c.getColumnIndexOrThrow("latitude")),
                    c.getString(c.getColumnIndexOrThrow("location")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_code")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_name")),
                    c.getString(c.getColumnIndexOrThrow("crime_type")),
                    c.getString(c.getColumnIndexOrThrow("last_outcome")),
                    c.getString(c.getColumnIndexOrThrow("context"))
            ));
        }
        c.close();

        rvResults.setAdapter(new CrimeAdapter(list, crime -> {
            Bundle b = new Bundle();
            b.putDouble("lat", crime.latitude);
            b.putDouble("lng", crime.longitude);
            b.putString("title", crime.crimeType);
            b.putString("snippet", crime.location);

            CrimeMapFragment map = new CrimeMapFragment();
            map.setArguments(b);

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, map)
                    .addToBackStack(null)
                    .commit();
        }));

        Toast.makeText(getContext(), "Results: " + list.size(), Toast.LENGTH_SHORT).show();
    }

    private String mapFieldToColumn(String f) {
        switch (f) {
            case "Month": return "month";
            case "Crime Type": return "crime_type";
            case "LSOA Name": return "lsoa_name";
            case "Reported By": return "reported_by";
            case "Location": return "location";
            default: return "crime_type";
        }
    }
}
