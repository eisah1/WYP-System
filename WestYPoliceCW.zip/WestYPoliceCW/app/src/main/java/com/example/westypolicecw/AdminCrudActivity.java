package com.example.westypolicecw;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.westypolicecw.adapters.CrimeAdapter;
import com.example.westypolicecw.db.CrimeDbHelper;
import com.example.westypolicecw.models.Crime;

import java.util.ArrayList;

public class AdminCrudActivity extends AppCompatActivity {

    private EditText etCrimeId, etMonth, etCrimeType, etLocation, etLatitude, etLongitude;
    private Button btnInsert, btnUpdate, btnDelete, btnViewAll;
    private RecyclerView rvAdminCrimes;

    private CrimeDbHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_crud);

        db = new CrimeDbHelper(this);

        // Bind views
        etCrimeId = findViewById(R.id.etCrimeId);
        etMonth = findViewById(R.id.etMonth);
        etCrimeType = findViewById(R.id.etCrimeType);
        etLocation = findViewById(R.id.etLocation);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);

        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnViewAll = findViewById(R.id.btnViewAll);

        rvAdminCrimes = findViewById(R.id.rvAdminCrimes);
        rvAdminCrimes.setLayoutManager(new LinearLayoutManager(this));

        // Button actions
        btnInsert.setOnClickListener(v -> insertCrime());
        btnUpdate.setOnClickListener(v -> updateCrime());
        btnDelete.setOnClickListener(v -> deleteCrime());
        btnViewAll.setOnClickListener(v -> loadAllCrimes());

        // Load existing data initially (optional but useful)
        loadAllCrimes();
    }

    private void insertCrime() {
        String id = etCrimeId.getText().toString().trim();
        if (id.isEmpty()) {
            toast("Crime ID is required");
            return;
        }

        Crime cr = buildCrimeFromInputs(true);
        if (cr == null) return;

        long result = db.insertCrime(cr);
        if (result != -1) {
            toast("Inserted / saved");
            loadAllCrimes();
            clearInputs();
        } else {
            toast("Insert failed");
        }
    }

    private void updateCrime() {
        String id = etCrimeId.getText().toString().trim();
        if (id.isEmpty()) {
            toast("Crime ID is required to update");
            return;
        }

        Crime cr = buildCrimeFromInputs(false);
        if (cr == null) return;

        int rows = db.updateCrime(cr);
        toast("Updated rows: " + rows);
        loadAllCrimes();
        clearInputs();
    }

    private void deleteCrime() {
        String id = etCrimeId.getText().toString().trim();
        if (id.isEmpty()) {
            toast("Crime ID is required to delete");
            return;
        }

        int rows = db.deleteCrime(id);
        toast("Deleted rows: " + rows);
        loadAllCrimes();
        clearInputs();
    }

    private void loadAllCrimes() {
        ArrayList<Crime> list = new ArrayList<>();
        Cursor c = db.getAllCrimes();

        while (c.moveToNext()) {
            list.add(new Crime(
                    c.getString(c.getColumnIndexOrThrow("crime_id")),
                    c.getString(c.getColumnIndexOrThrow("month")),
                    c.getString(c.getColumnIndexOrThrow("reported_by")),
                    c.getString(c.getColumnIndexOrThrow("falls_within")),
                    c.getDouble(c.getColumnIndexOrThrow("longitude")),
                    c.getDouble(c.getColumnIndexOrThrow("latitude")),
                    c.getString(c.getColumnIndexOrThrow("location")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_code")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_name")),
                    c.getString(c.getColumnIndexOrThrow("crime_type")),
                    c.getString(c.getColumnIndexOrThrow("last_outcome")),
                    c.getString(c.getColumnIndexOrThrow("context"))
            ));
        }
        c.close();

        rvAdminCrimes.setAdapter(new CrimeAdapter(list, crime -> {
            // When you tap a row, fill fields for easy update/delete
            etCrimeId.setText(crime.crimeId);
            etMonth.setText(crime.month);
            etCrimeType.setText(crime.crimeType);
            etLocation.setText(crime.location);
            etLatitude.setText(String.valueOf(crime.latitude));
            etLongitude.setText(String.valueOf(crime.longitude));
        }));

        toast("Loaded: " + list.size());
    }

    /**
     * Build a Crime object from fields.
     * For Insert we keep placeholder values for fields you didn't include on the CRUD screen.
     */
    private Crime buildCrimeFromInputs(boolean forInsert) {
        String id = etCrimeId.getText().toString().trim();
        String month = etMonth.getText().toString().trim();
        String type = etCrimeType.getText().toString().trim();
        String location = etLocation.getText().toString().trim();

        double lat, lng;
        try {
            lat = Double.parseDouble(etLatitude.getText().toString().trim());
            lng = Double.parseDouble(etLongitude.getText().toString().trim());
        } catch (Exception e) {
            toast("Latitude and Longitude must be valid numbers");
            return null;
        }

        // The dataset has more fields; we keep them as placeholders for CRUD screen
        String reportedBy = forInsert ? "Manual Entry" : "Manual Entry";
        String fallsWithin = forInsert ? "Manual Entry" : "Manual Entry";
        String lsoaCode = forInsert ? "" : "";
        String lsoaName = forInsert ? "" : "";
        String lastOutcome = forInsert ? "" : "";
        String context = forInsert ? "" : "";

        return new Crime(
                id,
                month,
                reportedBy,
                fallsWithin,
                lng,
                lat,
                location,
                lsoaCode,
                lsoaName,
                type,
                lastOutcome,
                context
        );
    }

    private void clearInputs() {
        etCrimeId.setText("");
        etMonth.setText("");
        etCrimeType.setText("");
        etLocation.setText("");
        etLatitude.setText("");
        etLongitude.setText("");
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
