package com.example.westypolicecw;

import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.westypolicecw.adapters.CrimeAdapter;
import com.example.westypolicecw.db.CrimeDbHelper;
import com.example.westypolicecw.models.Crime;

import java.util.ArrayList;

public class CrimeListFragment extends Fragment {

    private RecyclerView rv;
    private CrimeDbHelper db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_crime_list, container, false);

        rv = v.findViewById(R.id.rvCrimes);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));

        db = new CrimeDbHelper(requireContext());
        loadAllCrimes();

        return v;
    }

    private void loadAllCrimes() {

        ArrayList<Crime> list = new ArrayList<>();
        Cursor c = db.getAllCrimes();

        while (c.moveToNext()) {
            list.add(new Crime(
                    c.getString(c.getColumnIndexOrThrow("crime_id")),
                    c.getString(c.getColumnIndexOrThrow("month")),
                    c.getString(c.getColumnIndexOrThrow("reported_by")),
                    c.getString(c.getColumnIndexOrThrow("falls_within")),
                    c.getDouble(c.getColumnIndexOrThrow("longitude")),
                    c.getDouble(c.getColumnIndexOrThrow("latitude")),
                    c.getString(c.getColumnIndexOrThrow("location")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_code")),
                    c.getString(c.getColumnIndexOrThrow("lsoa_name")),
                    c.getString(c.getColumnIndexOrThrow("crime_type")),
                    c.getString(c.getColumnIndexOrThrow("last_outcome")),
                    c.getString(c.getColumnIndexOrThrow("context"))
            ));
        }

        c.close();

        rv.setAdapter(new CrimeAdapter(list, crime -> {

            Bundle b = new Bundle();
            b.putDouble("lat", crime.latitude);
            b.putDouble("lng", crime.longitude);
            b.putString("title", crime.crimeType);
            b.putString("snippet", crime.location);

            CrimeMapFragment map = new CrimeMapFragment();
            map.setArguments(b);

            requireActivity()
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, map)
                    .addToBackStack(null)
                    .commit();
        }));
    }

}



